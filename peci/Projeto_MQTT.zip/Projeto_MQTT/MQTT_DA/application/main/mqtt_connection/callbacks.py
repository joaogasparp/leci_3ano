from application.configs.broker_configs import mqtt_brokker_configs

def on_connect(client, userdata, flags, rc):
    if rc == 0:
        print(f"Conecção com sucesso: {client}\n")
        client.subscribe(mqtt_brokker_configs["TOPIC"])
    else:
        print(f"ERRO: codigo={rc}\n")


def on_subscribe(client, userdata, mid, granted_qos):
    print(f"Client Subscribed at {mqtt_brokker_configs['TOPIC']}")
    print(f"QOS: {granted_qos}")

def on_message(client, userdata, message):
    print("Mensagem Recebida!")
    print(client)
    print(message.payload)
