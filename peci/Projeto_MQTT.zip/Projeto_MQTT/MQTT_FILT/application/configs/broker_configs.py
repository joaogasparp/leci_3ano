mqtt_brokker_configs = {
    "HOST": "localhost",
    "PORT": 1883,
    "CLIENT_NAME": "client",
    "KEEPALIVE": 60,
    "TOPIC": "DF"
}

