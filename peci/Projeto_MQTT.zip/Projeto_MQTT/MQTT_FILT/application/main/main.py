import time
from application.configs.broker_configs import mqtt_brokker_configs
from .mqtt_connection.mqtt_client_connection import MqttClientConnection

def start():
    mqtt_client_connection = MqttClientConnection(
        mqtt_brokker_configs["HOST"],
        mqtt_brokker_configs["PORT"],
        mqtt_brokker_configs["CLIENT_NAME"],
        mqtt_brokker_configs["KEEPALIVE"],
    )
    mqtt_client_connection.start_connection()

    while True:
        time.sleep(0.001)