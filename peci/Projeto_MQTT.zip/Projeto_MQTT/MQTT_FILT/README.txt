============================
Programas a Instalar:

pip3 install paho-mqtt
============================