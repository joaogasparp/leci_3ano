from application.main.main import start


if __name__ == "__main__":
    start()