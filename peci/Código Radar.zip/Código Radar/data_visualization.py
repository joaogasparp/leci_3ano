import json
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
from createHistogram import *
from filtering import *
import numpy as np
import os
import datetime

from utils import parseConfigFile
from filtering import data_filtering


def get_hist_config(configFileName):
    configParameters = parseConfigFile(configFileName)

    maxRange = configParameters["maxRange"]
    maxVel = configParameters["maxVelocity"]
    rangeRes = configParameters["rangeResolutionMeters"]
    dopplerRes = configParameters["dopplerResolutionMps"]
    samplingInterval = configParameters["framePeriodicity"] / 1000  # ms to s

    return {"x": {"min": -maxRange, "max": maxRange, "res": rangeRes},
            "y": {"min": float(0), "max": maxRange, "res": rangeRes},
            "z": {"min": -maxRange, "max": maxRange, "res": rangeRes},
            "doppler": {"min": -maxVel, "max": maxVel, "res": dopplerRes},
            "range": {"min": float(0), "max": maxRange, "res": rangeRes},
            "peakVal": {"min": float(0), "max": float(500), "res": float(1)},
            "sampling_rate": float(1 / samplingInterval)}

    # return {"x": {"min": -maxRange, "max": maxRange, "res": rangeRes},
    #        "y": {"min": float(0), "max": maxRange, "res": rangeRes},
    #        "z": {"min": float(0), "max": maxRange, "res": rangeRes},
    #        "doppler": {"min": -maxVel, "max": maxVel, "res": dopplerRes},
    #        "sampling_rate": float(1 / samplingInterval)}


def get_radar_data(input, data_types):

    if type(input) == str:
        # input=json file name        
        # # Read JSON with data
        with open(input, "r") as f:
            json_data = json.load(f)

        if not json_data:
            return

        data = {}
        for data_type in data_types:
            if data_type not in data:
                data.update({data_type: []})
            for frame_nr, all_data in json_data.items():
                data[data_type].append([val for val in all_data[data_type]])

    else:
        data = {}
        for data_type in data_types:
            if data_type not in data:
                data.update({data_type: []})
            for frame_nr, all_data in input.items():
                data[data_type].append([val for val in all_data[data_type]])
    return data


def get_histograms(data, config_info, data_types, dest_folder_path, json_filename):
    
    # Change mininum, maximum, and resolution values for visualization
    # config_info["x"]["min"] = -1.5
    # config_info["x"]["max"] = 1.5
    # config_info["x"]["res"] = 0.1
    # config_info["y"]["min"] = 0.5
    # config_info["y"]["max"] = 2.5
    # config_info["y"]["res"] = 0.1
    
    x = datetime.datetime.now()

    new_folder_name = (x.strftime("%d-%m-%y"))
    name = (x.strftime("%H-%M-%S"))

    for data_type in data_types:
        create_histogram(data, "time", data_type, dest_folder_path, new_folder_name, name, config_info)

    # X Y Map
    #create_histogram(data, "x", "y", dest_folder_path, new_folder_name, name, config_info)
    create_histogram(data, "z", "y", dest_folder_path, new_folder_name, name, config_info)

    # Range Doppler Heat Map
    # create_histogram(data, "range", "doppler", dest_folder_path, new_folder_name, name, config_info)


def animate(i):
    global fig
    global ax
    global final_x_data
    global final_y_data
    global cbar

    # ax.clear()
    # fig.clear()
    hist = ax.hist2d(final_x_data[i], final_y_data[i], range=[[0, 2.5], [0, 6]], bins=[25, 60])

    if cbar:
        cbar.remove()
    cbar = fig.colorbar(hist[3])
    cbar.ax.set_ylabel('No. detected targets')


def get_animated_histogram(data, config_info):
    global fig
    global ax
    global cbar
    global final_x_data
    global final_y_data

    x_axis_data = data["x"]
    y_axis_data = data["y"]
    radar_frame_rate = int(config_info["sampling_rate"])  # in Hz

    final_x_data = []
    final_y_data = []

    win_nr = 0
    i = 0
    while i < len(x_axis_data):

        x_axis_data_win = x_axis_data[i:i + radar_frame_rate]
        y_axis_data_win = y_axis_data[i:i + radar_frame_rate]

        win_nr += 1

        x_data = []
        y_data = []
        for j in range(0, len(x_axis_data_win)):
            x_vals = np.asarray(x_axis_data_win[j]).tolist()
            y_vals = np.asarray(y_axis_data_win[j]).tolist()
            if type(x_vals) == list and len(x_vals) == 1:
                x_vals = x_vals[0]
                y_vals = y_vals[0]
            if type(x_vals) == float:
                x_vals = [x_vals]
                y_vals = [y_vals]

            x_data += x_vals
            y_data += y_vals

        if win_nr == 1:
            final_x_data.append(x_data)
            final_y_data.append(y_data)
        elif win_nr > 1:
            final_x_data.append(x_data + final_x_data[win_nr - 2])
            final_y_data.append(y_data + final_y_data[win_nr - 2])

        i += radar_frame_rate

    fig, ax = plt.subplots(tight_layout=True)
    plt.title("Y-X Map")
    plt.ylabel("Y coordinate (m)")
    plt.xlabel("X coordinate (m)")

    cbar = None

    # ax.set_xlim([0, 5])
    # ax.set_ylim([-5, 5])

    ani = FuncAnimation(fig, animate, frames=len(final_x_data), interval=1000, repeat=False)

    plt.show()


def data_visualization():
    data_types = ["x", "y", "z", "doppler", "range", "peakVal"]
    # data_types = ["x", "y", "velocity"]

    folder = r""
    filename = ""

    # Get the relevant values from the configuration file used to acquire the data
    config_file_path = os.path.join(folder, 'config1.cfg')
    config_vals = get_hist_config(config_file_path)

    # Get the acquired data from the JSON file
    json_filename = os.path.join(folder, filename + ".json")
    data = get_radar_data(json_filename, data_types)

    # Obtain the relevant histograms for the different data types
    # get_histograms(data, config_vals, data_types, folder, json_filename)

    # Filter the data
    data_filtered = data_filtering(data["x"], data["y"], data["z"], data["doppler"], data["range"], data["peakVal"])
    # data_filtered = filtering(data["x"], data["y"], None, data["velocity"], None, None)

    if data_filtered:
        # Obtain the relevant histograms for the different data types
        get_histograms(data_filtered, config_vals, data_types, folder, json_filename)

        # get_animated_histogram(data_filtered, config_vals)


if __name__ == '__main__':
    processData()
