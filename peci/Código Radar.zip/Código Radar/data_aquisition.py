import json
import os.path
import struct

import serial
import time
import numpy as np
import pyqtgraph as pg
from pyqtgraph.Qt import QtGui
import paho.mqtt.client as mqtt

from utils import parseConfigFile


CLIport = {}
Dataport = {}
byteBuffer = np.zeros(2 ** 15, dtype='uint8')
byteBufferLength = 0


# ------------------------------------------------------------------

# Function to configure the serial ports and send the data from
# the configuration file to the radar
def serialConfig(config_file_path, port_config, port_data):
    global CLIport
    global Dataport
    
    # Open the serial ports for the configuration and the data ports

    # Linux
    # CLIport = serial.Serial('/dev/ttyACM0', 115200)
    # Dataport = serial.Serial('/dev/ttyACM1', 921600)

    # Windows
    CLIport = serial.Serial(port_config, 115200)
    Dataport = serial.Serial(port_data, 921600)

    # Read the configuration file and send it to the board
    config = [line.rstrip('\r\n') for line in open(config_file_path)]
    for i in config:
        CLIport.write((i + '\n').encode())
        print(i)
        time.sleep(0.01)

    return CLIport, Dataport


# ------------------------------------------------------------------

# Funtion to read and parse the incoming data
def readAndParseData16xx(Dataport, config_params):
    global byteBuffer, byteBufferLength

    # Constants
    OBJ_STRUCT_SIZE_BYTES = 12
    BYTE_VEC_ACC_MAX_SIZE = 2 ** 15
    MMWDEMO_UART_MSG_DETECTED_POINTS = 1
    MMWDEMO_UART_MSG_RANGE_PROFILE = 2
    maxBufferSize = 2 ** 15
    magicWord = [2, 1, 4, 3, 6, 5, 8, 7]

    # Initialize variables
    magicOK = -1  # Checks if magic number has been read
    dataOK = 0  # Checks if the data has been read correctly
    frameNumber = 0
    detObj = {}
    tlv_type = 0

    readBuffer = Dataport.read(Dataport.in_waiting)

    if len(readBuffer) == 0:
        # print("Empty data")
        return dataOK, None, None

    byteVec = np.frombuffer(readBuffer, dtype='uint8')
    byteCount = len(byteVec)

    # Check that the buffer is not full, and then add the data to the buffer
    if (byteBufferLength + byteCount) < maxBufferSize:
        byteBuffer[byteBufferLength:byteBufferLength + byteCount] = byteVec[:byteCount]
        byteBufferLength = byteBufferLength + byteCount

    # Check that the buffer has some data
    if byteBufferLength > 16:

        # Check for all possible locations of the magic word
        possibleLocs = np.where(byteBuffer == magicWord[0])[0]

        # Confirm that is the beginning of the magic word and store the index in startIdx
        startIdx = []
        for loc in possibleLocs:
            check = byteBuffer[loc:loc + 8]
            if np.all(check == magicWord):
                startIdx.append(loc)

        # Check that startIdx is not empty
        if startIdx:

            # Remove the data before the first start index
            if startIdx[0] > 0 and startIdx[0] < byteBufferLength:
                byteBuffer[:byteBufferLength - startIdx[0]] = byteBuffer[startIdx[0]:byteBufferLength]
                byteBuffer[byteBufferLength - startIdx[0]:] = np.zeros(len(byteBuffer[byteBufferLength - startIdx[0]:]),
                                                                       dtype='uint8')
                byteBufferLength = byteBufferLength - startIdx[0]

            # Check that there have no errors with the byte buffer length
            if byteBufferLength < 0:
                byteBufferLength = 0

            # word array to convert 4 bytes to a 32 bit number
            word = [1, 2 ** 8, 2 ** 16, 2 ** 24]

            # Read the total packet length
            totalPacketLen = np.matmul(byteBuffer[12:12 + 4], word)

            # Check that all the packet has been read
            if (byteBufferLength >= totalPacketLen) and (byteBufferLength != 0):
                magicOK = 1
            else:
                magicOK = 0

    # If magicOK is equal to 1 then process the message
    if magicOK == 1:
        # word array to convert 4 bytes to a 32 bit number
        word = [1, 2 ** 8, 2 ** 16, 2 ** 24]

        # Initialize the pointer index
        idX = 0

        # Read the header
        magicNumber = byteBuffer[idX:idX + 8]
        idX += 8
        version = format(np.matmul(byteBuffer[idX:idX + 4], word), 'x')
        idX += 4
        totalPacketLen = np.matmul(byteBuffer[idX:idX + 4], word)
        idX += 4
        platform = format(np.matmul(byteBuffer[idX:idX + 4], word), 'x')
        idX += 4
        frameNumber = np.matmul(byteBuffer[idX:idX + 4], word)
        idX += 4
        timeCpuCycles = np.matmul(byteBuffer[idX:idX + 4], word)
        idX += 4
        numDetectedObj = np.matmul(byteBuffer[idX:idX + 4], word)
        idX += 4
        numTLVs = np.matmul(byteBuffer[idX:idX + 4], word)
        idX += 4
        subFrameNumber = np.matmul(byteBuffer[idX:idX + 4], word)
        idX += 4

        # Read the TLV messages
        for tlvIdx in range(numTLVs):

            # word array to convert 4 bytes to a 32 bit number
            word = [1, 2 ** 8, 2 ** 16, 2 ** 24]

            # Check the header of the TLV message
            try:
                tlv_type = np.matmul(byteBuffer[idX:idX + 4], word)
                idX += 4
                tlv_length = np.matmul(byteBuffer[idX:idX + 4], word)
                idX += 4
            except:
                pass

            # Read the data depending on the TLV message
            if tlv_type == MMWDEMO_UART_MSG_DETECTED_POINTS:

                tlv_numObj = None
                tlv_xyzQFormat = None
                rangeIdx = None
                dopplerIdx = None
                peakVal = None
                x = None
                y = None
                z = None
                velocity = None

                if version == "2000004" or version == "2010004":
                    # word array to convert 4 bytes to a 16 bit number
                    word = [1, 2 ** 8]
                    tlv_numObj = np.matmul(byteBuffer[idX:idX + 2], word)
                    idX += 2
                    tlv_xyzQFormat = 2 ** np.matmul(byteBuffer[idX:idX + 2], word)
                    idX += 2

                    # Initialize the arrays
                    rangeIdx = np.zeros(tlv_numObj, dtype='int16')
                    dopplerIdx = np.zeros(tlv_numObj, dtype='int16')
                    peakVal = np.zeros(tlv_numObj, dtype='int16')
                    x = np.zeros(tlv_numObj, dtype='int16')
                    y = np.zeros(tlv_numObj, dtype='int16')
                    z = np.zeros(tlv_numObj, dtype='int16')

                elif version == "3040003" or version == "3060000":
                    # word array to convert 4 bytes to a 32 bit number
                    word = [1, 2 ** 8, 2 ** 16, 2 ** 24]
                    tlv_numObj = numDetectedObj

                    # Initialize the arrays
                    velocity = np.zeros(tlv_numObj, dtype='float32')
                    x = np.zeros(tlv_numObj, dtype='float32')
                    y = np.zeros(tlv_numObj, dtype='float32')
                    z = np.zeros(tlv_numObj, dtype='float32')

                for objectNum in range(tlv_numObj):

                    #print(objectNum)

                    if version == "2000004" or version == "2010004":
                        # Read the data for each object
                        rangeIdx[objectNum] = np.matmul(byteBuffer[idX:idX + 2], word)
                        idX += 2
                        dopplerIdx[objectNum] = np.matmul(byteBuffer[idX:idX + 2], word)
                        idX += 2
                        peakVal[objectNum] = np.matmul(byteBuffer[idX:idX + 2], word)
                        idX += 2
                        x[objectNum] = np.matmul(byteBuffer[idX:idX + 2], word)
                        idX += 2
                        y[objectNum] = np.matmul(byteBuffer[idX:idX + 2], word)
                        idX += 2
                        z[objectNum] = np.matmul(byteBuffer[idX:idX + 2], word)
                        idX += 2
                    elif version == "3040003" or version == "3060000":
                        # x[objectNum] = np.matmul(byteBuffer[idX:idX + 4], word)
                        x[objectNum] = struct.unpack('<f', byteBuffer[idX:idX + 4])[0]
                        idX += 4
                        # y[objectNum] = np.matmul(byteBuffer[idX:idX + 4], word)
                        y[objectNum] = struct.unpack('<f', byteBuffer[idX:idX + 4])[0]
                        idX += 4
                        # z[objectNum] = np.matmul(byteBuffer[idX:idX + 4], word)
                        z[objectNum] = struct.unpack('<f', byteBuffer[idX:idX + 4])[0]
                        idX += 4
                        # velocity[objectNum] = np.matmul(byteBuffer[idX:idX + 4], word)
                        velocity[objectNum] = struct.unpack('<f', byteBuffer[idX:idX + 4])[0]
                        idX += 4

                if version == "2000004" or version == "2010004":
                    # Make the necessary corrections and calculate the rest of the data
                    rangeVal = rangeIdx * config_params["rangeIdxToMeters"]
                    dopplerIdx[dopplerIdx > (config_params["numDopplerBins"] / 2 - 1)] = dopplerIdx[dopplerIdx > (
                                config_params["numDopplerBins"] / 2 - 1)] - 65535
                    dopplerVal = dopplerIdx * config_params["dopplerResolutionMps"]
                    # x[x > 32767] = x[x > 32767] - 65536
                    # y[y > 32767] = y[y > 32767] - 65536
                    # z[z > 32767] = z[z > 32767] - 65536

                    if tlv_xyzQFormat:
                        x = x / tlv_xyzQFormat
                        y = y / tlv_xyzQFormat
                        z = z / tlv_xyzQFormat

                    # Store the data in the detObj dictionary
                    detObj = {"numObj": int(tlv_numObj), "rangeIdx": rangeIdx.tolist(), "range": rangeVal.tolist(),
                              "dopplerIdx": dopplerIdx.tolist(), "doppler": dopplerVal.tolist(),
                              "peakVal": peakVal.tolist(), "x": x.tolist(), "y": y.tolist(), "z": z.tolist()}

                elif version == "3040003" or version == "3060000":
                    # Store the data in the detObj dictionary
                    detObj = {"numObj": int(tlv_numObj), "x": x.tolist(), "y": y.tolist(), "z": z.tolist(),
                              "velocity": velocity.tolist()}

                dataOK = 1

        # Remove already processed data
        if 0 < idX < byteBufferLength:
            shiftSize = totalPacketLen

            byteBuffer[:byteBufferLength - shiftSize] = byteBuffer[shiftSize:byteBufferLength]
            byteBuffer[byteBufferLength - shiftSize:] = np.zeros(len(byteBuffer[byteBufferLength - shiftSize:]),
                                                                 dtype='uint8')
            byteBufferLength = byteBufferLength - shiftSize

            # Check that there are no errors with the buffer length
            if byteBufferLength < 0:
                byteBufferLength = 0
    elif magicOK == 0:
        print("Wrong magic word - 1" + str(frameNumber))
    elif magicOK == -1:
        print("Wrong magic word - 2" + str(frameNumber))

    return dataOK, frameNumber, detObj


# ------------------------------------------------------------------

# Funtion to update the data and display in the plot
def update():

    global detObj

    # Read and parse the received data
    dataOk, frameNumber, detObj = readAndParseData16xx(Dataport, config_params)

    if dataOk and len(detObj["x"]) > 0:

        print(frameNumber)
        # print(detObj)

        x = detObj["x"]
        y = detObj["y"]

        #s.setData(x, y)
        #QtGui.QApplication.processEvents()

    return dataOk


# -------------------------    MAIN   -----------------------------------------  

if __name__ == '__main__':

    # Radar Ports (COMX for Windows)
    port_config = "COM7"
    port_data = "COM6"

    # Destination folder for the acquisitions
    folder = r""

    # Configuration file name
    config_file_path = os.path.join(folder, 'config1.cfg')

    # Path of file to be saved
    filename = "test"
    filepath = os.path.join(folder,filename + ".json")

    # Configure the serial port
    CLIport, Dataport = serialConfig(config_file_path, port_config, port_data)

    # Get the configuration parameters from the configuration file
    config_params = parseConfigFile(config_file_path)

    # Main loop
    detObj = {}
    frameData = {}
    currentIndex = 0

    while True:
        try:
            # Update the data and check if the data is okay
            dataOk = update()

            if dataOk:
                # Store the current frame into frameData
                frameData[currentIndex] = detObj
                currentIndex += 1
                # print(currentIndex)

            time.sleep(1/(config_params["periodicity"]/1000))  # periodicity is in ms

        # Stop the program and close everything if Ctrl + c is pressed
        except KeyboardInterrupt:
            CLIport.write('sensorStop\n'.encode())
            CLIport.close()
            Dataport.close()

            if frameData:
                with open(filename, "w") as f:
                    json.dump(frameData, f, indent=4)

            break
