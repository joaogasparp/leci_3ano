import numpy as np
import matplotlib.pyplot as plt
import os


def create_histogram(data, data_type_x, data_type_y, folder_path, new_folder_name, name, config_info):
    new_path = folder_path + "\Histograms\\" + new_folder_name

    if not os.path.exists(new_path):
        os.makedirs(new_path)

    sampling_rate = config_info["sampling_rate"]

    # date_type_x != "time" vs == "time"
    if data_type_x != "time":
        x_min = config_info[data_type_x]["min"]
        x_max = config_info[data_type_x]["max"]
        x_res = config_info[data_type_x]["res"]

    y_min = config_info[data_type_y]["min"]
    y_max = config_info[data_type_y]["max"]
    y_res = config_info[data_type_y]["res"]

    n_frames = len(data[data_type_y])

    if data_type_x == "time":
        elapsed_time = list(np.arange(0, n_frames / sampling_rate, 1 / sampling_rate))

    x = []
    y = []

    # Transform data for histogram
    for i in range(0, n_frames - 1):
        if not hasattr(data[data_type_y][i], "__len__"):
            data[data_type_y][i] = [data[data_type_y][i]]

        n_targets = len(data[data_type_y][i])

        if data_type_x != "time":
            for j in range(0, n_targets - 1):
                x.append(data[data_type_x][i][j])
                y.append(data[data_type_y][i][j])
        else:
            for j in range(0, n_targets - 1):
                x.append(elapsed_time[i])
                y.append(data[data_type_y][i][j])

    y_bin_edges = list(np.arange(y_min, y_max, y_res))

    if data_type_x != "time":
        x_bin_edges = list(np.arange(x_min, x_max, x_res))
        filename = name + "_" + data_type_y + "_" + data_type_x

    else:
        x_bin_edges = elapsed_time
        filename = name + "_" + data_type_y

    fig, ax = plt.subplots()

    # Histogram
    hist = ax.hist2d(x, y, bins=[x_bin_edges, y_bin_edges], cmap='plasma')

    plt.title(data_type_y + "-" + data_type_x + " Map")
    plt.ylabel(get_label_by_data_type(data_type_y), fontsize=14)
    plt.xlabel(get_label_by_data_type(data_type_x), fontsize=14)
    fig.colorbar(hist[3], ax=ax)

    hist_filename = os.path.join(new_path, filename + ".png")

    # Save histograms in dir
    plt.savefig(hist_filename)

    # Show histograms
    # plt.show()

    # sendData(fig, filename)


def get_label_by_data_type(data_type):
    if data_type == "x":
        return 'X Coordinate (m)'
    elif data_type == "y":
        return 'Y Coordinate (m)'
    elif data_type == "range":
        return 'Range (m)'
    elif data_type == "doppler":
        return 'Doppler velocity (m/s)'
    elif data_type == "time":
        return 'Elapsed time (s)'
