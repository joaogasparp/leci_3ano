import numpy as np


def data_filtering(x, y, z, doppler, range_, peakVal):
    x_filtered = []
    y_filtered = []
    z_filtered = []
    doppler_filtered = []
    range_filtered = []
    peakVal_filtered = []

    # For each frame
    for i in range(0, len(doppler) - 1):
        frameX = x[i]
        frameY = y[i]
        frameDopp = doppler[i]

        if z and len(z) > 0:
            frameZ = z[i]

        if range_ and len(range_) > 0:
            frameRange = range_[i]

        if peakVal and len(peakVal) > 0:
            framePeakVal = peakVal[i]

        ind_selection = (np.absolute(frameDopp) > 1e-5)

        frameX_filtered = [i for indx, i in enumerate(frameX) if ind_selection[indx]]
        x_filtered.append(frameX_filtered)

        frameY_filtered = [i for indx, i in enumerate(frameY) if ind_selection[indx]]
        y_filtered.append(frameY_filtered)

        frameDopp_filtered = [i for indx, i in enumerate(frameDopp) if ind_selection[indx]]
        doppler_filtered.append(frameDopp_filtered)

        if z and len(z) > 0:
            frameZ_filtered = [i for indx, i in enumerate(frameZ) if ind_selection[indx]]
            z_filtered.append(frameZ_filtered)

        if range_ and len(range_) > 0:
            frameRange_filtered = [i for indx, i in enumerate(frameRange) if ind_selection[indx]]
            range_filtered.append(frameRange_filtered)

        if peakVal and len(peakVal) > 0:
            framePeakVal_filtered = [i for indx, i in enumerate(framePeakVal) if ind_selection[indx]]
            peakVal_filtered.append(framePeakVal_filtered)

    data = {'x': x_filtered,
            'y': y_filtered,
            'z': z_filtered,
            'doppler': doppler_filtered,
            'range': range_filtered,
            'peakVal': peakVal_filtered
            }
    # data = {'x': x_filtered,
    #        'y': y_filtered,
    #        'z': z_filtered,
    #        'velocity': doppler_filtered
    #        }

    return (data)
